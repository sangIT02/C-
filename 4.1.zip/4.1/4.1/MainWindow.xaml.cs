﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _4._1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<NhanVien> listNV = new List<NhanVien>();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void btn_Them_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (txt_MaNV.Text == "")
                {
                    MessageBox.Show("Vui lòng không để trống Mã nhân viên");
                    return;
                }
                if (listNV.Any(nv => nv.MaNV == txt_MaNV.Text))
                {
                    MessageBox.Show("Mã nhân viên đã tồn tại");
                    return;
                }
                if (txt_HoTen.Text == "")
                {
                    MessageBox.Show("vui lòng không để trống họ tên");
                    return;
                }
                if (!double.TryParse(txt_SoTien.Text, out double tien))
                {
                    MessageBox.Show("vui lòng nhập số tiền");
                    return;
                }
                if (tien < 0)
                {
                    MessageBox.Show("số tiền phải lớn hơn 0");
                    return;
                }
                string gt = rbtn_Nam.IsChecked == true ? "Nam" : "Nữ";
                NhanVien nv = new NhanVien(txt_MaNV.Text, txt_HoTen.Text, gt, tien);
                listNV.Add(nv);
                datagrid.ItemsSource = listNV;
                datagrid.Items.Refresh();
            }catch (Exception ex)
            {
                MessageBox.Show("có lỗi khi thêm nhân viên");
            }
        }

        private void btn_Window2_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                NhanVien mtien = listNV.OrderByDescending(t => t.SoTienBanHang).FirstOrDefault();
                List<NhanVien> n2 = listNV.Where(nv => nv.SoTienBanHang == mtien.SoTienBanHang).ToList();
                Window2 w2 = new Window2(n2);
                w2.ShowDialog();
            }catch(Exception ex)
            {
                MessageBox.Show("có lỗi khi mở window2");
            }
        }
    }
}