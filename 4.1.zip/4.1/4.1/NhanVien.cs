﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4._1
{
    public class NhanVien
    {
        public NhanVien()
        {
        }

        public string MaNV { get; set; }
        public string HoTen { get; set; }
        public string GioiTinh { get; set; }
        public double SoTienBanHang { get; set; }
        public double TienHoaHong { get; set; }

        public NhanVien(string maNV, string hoTen, string gioiTinh, double soTienBanHang )
        {
            MaNV = maNV;
            HoTen = hoTen;
            GioiTinh = gioiTinh;
            SoTienBanHang = soTienBanHang;
            TienHoaHong = 0.1*SoTienBanHang;
        }
    }
}
